package game.city.person;

public class Player extends Person{

	public Player(String name, double velocity) {
		super(name, velocity);
	}

}
